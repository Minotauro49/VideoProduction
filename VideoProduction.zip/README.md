﻿		    # VideoProduction


---------------- -VideoProduction.xlsm- ---------------- 

• To open (VideoProduction.xlsm); Open using Excel.

• Enable any warnings that Excel alerts ("The file will not harm your computer").

• You will see what you edited on the web app displayed on the graph

• You can navigate to other pages below, Example BorrowedEqp and DataBase 
